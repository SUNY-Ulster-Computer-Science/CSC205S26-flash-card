import javax.swing.*;
import java.awt.*;

public class FlashCardUI extends JFrame {
    private FlashCardManager manager;
    private JList<FlashCard> cardList;
    private DefaultListModel<FlashCard> listModel;
    private JTextArea questionArea, answerArea;

    public FlashCardUI() {
        manager = new FlashCardManager();

        setTitle("Flash Card App");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        listModel = new DefaultListModel<>();
        cardList = new JList<>(listModel);
        add(new JScrollPane(cardList), BorderLayout.WEST);

        JPanel panel = new JPanel(new GridLayout(2,1));
        questionArea = new JTextArea("Question...");
        answerArea = new JTextArea("Answer...");
        panel.add(new JScrollPane(questionArea));
        panel.add(new JScrollPane(answerArea));
        add(panel, BorderLayout.CENTER);

        JPanel buttons = new JPanel();

        JButton addBtn = new JButton("Add");
        JButton updateBtn = new JButton("Update");
        JButton deleteBtn = new JButton("Delete");
        JButton showBtn = new JButton("Show Answer");
        JButton shuffleBtn = new JButton("Shuffle");

        buttons.add(addBtn);
        buttons.add(updateBtn);
        buttons.add(deleteBtn);
        buttons.add(showBtn);
        buttons.add(shuffleBtn);

        add(buttons, BorderLayout.SOUTH);

        addBtn.addActionListener(e -> {
            manager.addCard(questionArea.getText(), answerArea.getText());
            refreshList();
        });

        updateBtn.addActionListener(e -> {
            int index = cardList.getSelectedIndex();
            manager.updateCard(index, questionArea.getText(), answerArea.getText());
            refreshList();
        });

        deleteBtn.addActionListener(e -> {
            int index = cardList.getSelectedIndex();
            manager.deleteCard(index);
            refreshList();
        });

        showBtn.addActionListener(e -> {
            int index = cardList.getSelectedIndex();
            if (index != -1) {
                FlashCard card = manager.getCards().get(index);
                JOptionPane.showMessageDialog(this, card.getAnswer());
            }
        });

        shuffleBtn.addActionListener(e -> {
            manager.shuffleCards();
            refreshList();
        });

        cardList.addListSelectionListener(e -> {
            int index = cardList.getSelectedIndex();
            if (index != -1) {
                FlashCard card = manager.getCards().get(index);
                questionArea.setText(card.getQuestion());
                answerArea.setText(card.getAnswer());
            }
        });
    }

    private void refreshList() {
        listModel.clear();
        for (FlashCard card : manager.getCards()) {
            listModel.addElement(card);
        }
    }
}
