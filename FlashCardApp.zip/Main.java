public class Main {
    public static void main(String[] args) {
        new FlashCardUI().setVisible(true);
    }
}
